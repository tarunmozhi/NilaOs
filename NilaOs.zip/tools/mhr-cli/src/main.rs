use anyhow::{bail,Result};
use mhr_core::{analyze,create_manifest};
use std::env;
fn usage(){eprintln!("Usage:\n  mhr-cli analyze <file>\n  mhr-cli manifest <file> <name> <version>");}
fn main()->Result<()>{let mut a=env::args().skip(1);match a.next().unwrap_or_default().as_str(){"analyze"=>{let f=a.next().ok_or_else(||anyhow::anyhow!("missing file"))?;println!("{}",serde_json::to_string_pretty(&analyze(&f)?)?);},"manifest"=>{let f=a.next().ok_or_else(||anyhow::anyhow!("missing file"))?;let n=a.next().ok_or_else(||anyhow::anyhow!("missing name"))?;let v=a.next().ok_or_else(||anyhow::anyhow!("missing version"))?;let x=analyze(&f)?;if !x.supported{bail!("input format is recognized but unsupported by this build")}println!("{}",serde_json::to_string_pretty(&create_manifest(&x,&n,&v))?);},_=>{usage();bail!("unknown command")}}Ok(())}
