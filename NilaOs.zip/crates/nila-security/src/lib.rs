use serde::{Deserialize,Serialize};
#[derive(Debug,Clone,Serialize,Deserialize)]
pub struct SecurityPolicy { pub selinux_enforcing:bool,pub require_signed_packages:bool,pub require_integrity:bool,pub deny_root_to_apps:bool,pub audit_privileged_actions:bool }
impl Default for SecurityPolicy { fn default()->Self{Self{selinux_enforcing:true,require_signed_packages:true,require_integrity:true,deny_root_to_apps:true,audit_privileged_actions:true}} }
pub fn production_policy()->SecurityPolicy{SecurityPolicy::default()}
#[cfg(test)] mod tests {use super::*;#[test]fn production_policy_is_hardened(){let p=production_policy();assert!(p.selinux_enforcing&&p.require_signed_packages&&p.require_integrity&&p.deny_root_to_apps&&p.audit_privileged_actions);}}
